let ms1_hours_worked = 38
