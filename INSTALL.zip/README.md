# clans
### Cellular Life Automaton Nation Simulation

Final Project for CS 3110 at Cornell University

Created by Ari, Edmund, Noah, Rigel

# Installation Guide

See [the installation guide here](/INSTALL.md).
